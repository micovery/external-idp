
print('authCodeCache: ' + context.getVariable('authCodeCache'));
