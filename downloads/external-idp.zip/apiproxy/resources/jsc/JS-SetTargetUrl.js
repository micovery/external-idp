context.setVariable('target.url', context.getVariable('request-url'));
context.setVariable('target.copy.pathsuffix', false);
context.setVariable('target.copy.queryparams', false);
 